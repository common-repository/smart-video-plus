<?
require('wp-config.php');
$user = DB_USER ;
$password = DB_PASSWORD  ;
$dababase = DB_NAME ; 
$server = DB_HOST ;
$link = mysql_connect($server, $user, $password);
 if (!$link){
		die ("Couldn't connect to mySQL server");
 }
 if (!mysql_select_db ($dababase,$link)){
		die ("Coldn't open $db: ".mysql_error() );
 }
 $postID = $_REQUEST['postID'];
 $sql = "select meta_value from wp_postmeta where post_id = ".$postID." and meta_key = 'videoswiper-embed-code'" ;
 $rs = mysql_query($sql); echo mysql_error();
 if( $row = mysql_fetch_array($rs)) 
 	echo $row['meta_value'];
?>