<?php
/*
Plugin Name: Videoswiper
Plugin URI: http://www.route66solutions.com/products/smart-video-plus.php
Description: Videoswiper, turns your WordPress into a full video CMS for running a video website & allows you to either add video embeds manually or mass embed through a VideoSwiper account.
Version: 3.0
Author: Videoswiper
Author URI: http://www.route66solutions.com
*/
/*	----------------------------------------------------------------------------
 	    ____________________________________________________
       |                                                    |
       |             VideoSwiper Wordpress Plugin               |
       |                � VideoSwiper.com                  |
       |____________________________________________________|
	� Copyright 2006-2010 VideoSwiper.com
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    --------------------------------------------------------------------------*/
add_filter('the_content', '_videoswiper_filter_content');
add_action('admin_menu', 'addPluginToSubmenu');
function addPluginToSubmenu()
{
        add_submenu_page('post-new.php', 'Submit Video', 'Submit Video', 10, __FILE__, 'manualSubmit');
}
function manualSubmit (){
        if(isset($_POST['submit'])){
                $ok = 1;
                if($_POST['embed'] == ''){
                        $ok = 0;
                        $check_embed = 1;
                }
                if($_POST['thumb'] == ''){
                        $ok = 0;
                        $check_thumb = 1;
                }
                if($_POST['title'] == ''){
                        $ok = 0;
                        $check_title = 1;
                }
                if($ok){
                        $my_post = array();
                        $my_post['post_title'] = $_POST['title'];
                        $my_post['post_content'] = $_POST['description'];
                        $my_post['post_status'] = 'publish';
                        $my_post['tags_input'] = $_POST['tags'];
                        $my_post['post_category'] = array($_POST['category']);
                        $id = wp_insert_post($my_post);
                        if($id){
                        add_post_meta($id, 'videoswiper-embed-code',$_POST['embed']);
                        add_post_meta($id, 'videoswiper-embed-thumb',$_POST['thumb']);
?>                        
<div class="wrap"><h2>&nbsp</h2>
  <div class="updated" id="message" style="background-color: rgb(255, 251, 204);">
    <p><strong>Video was added successfully.</strong>
  </div>
</div>                        
<?php
                        }else{
?>                        
<div class="wrap"><h2>&nbsp</h2>
  <div class="updated" id="message" style="background-color: rgb(255, 251, 204);">
    <p><strong>There was an error when adding the video.</strong>
  </div>
</div>                        
<?php
                        }
                        return;
                }
        }
?>
<div class="wrap">
  <table style="margin-top:15px;" cellpadding="5" cellspacing="0" width="100%">
    <tr>
      <td valign="top" style="width:500px;padding-right:10px;" align="left">
        <center>
          <a href="http://www.videoswiper.com/">
            <img src="../wp-content/plugins/videoswiper/images/vs_logo_v2.png" border="0"></a>
        </center><br />
        <p>Did you know that this video plugin is already fully connected to the online video application 
          <a target="_blank" href="http://www.videoswiper.com">VideoSwiper</a> Why not save yourself hours of adding content, copying and pasting and just connect straight up to VideoSwiper and choose from over 150 million videos to mass embed to your WordPress website. Adding videos one by one & trying to find thumbnail images is like having to do data entry all day long, STOP & think just how easy it would be for an application to do  the whole process for you just by adding keywords! A rock solid system that works everytime, it will save you money, effort, time and boring data entry plus you will build huge wordpress video websites in no time at all using the VideoSwiper application, 18,000 members can't be wrong!
        </p></td>
      <td valign="top" style="padding-left:10px;padding-right:10px;border-left:1px solid #ddd;" align="left"><b>Here's a quick video to show you how it works!</b> 
        <a target=_blank" href="http://www.route66solutions.com/view-content/8-smartvideoplus-demo-video.html">Click Here</a><br /><br />Watch this awesome tutorial video & see just how easy it is to hook up your WordPress site to the VideoSwiper application to mass embed millions of videos in any targeted niche.<br /><br />
        <ul><li>
          <img style="vertical-align:middle;" src="../wp-content/plugins/videoswiper/images/tick.gif" border="0"> Can embed over 1000 videos every 180 seconds to your WordPress</li><li>
          <img style="vertical-align:middle;" src="../wp-content/plugins/videoswiper/images/tick.gif" border="0"> Bulk change meta titles, descriptions & tags on the fly</li><li>
          <img style="vertical-align:middle;" src="../wp-content/plugins/videoswiper/images/tick.gif" border="0"> Choose from over 150 million videos in 1000's of targeted niches</li><li>
          <img style="vertical-align:middle;" src="../wp-content/plugins/videoswiper/images/tick.gif" border="0"> NO downloading & NO uploading, fully automated system does the work for you</li><li>
          <img style="vertical-align:middle;" src="../wp-content/plugins/videoswiper/images/tick.gif" border="0"> Simply Search! Save! & Send! job done & in record time!</li><li>Try 
          <a target="_blank" href="http://www.videoswiper.com">VideoSwiper</a> Totally FREE! NO Obligation to Buy Credits...</li>
        </ul></td>
    </tr>
  </table>
</div>
<?php
        if(isset($_POST['submit'])){
                if($_POST['embed'] == ''){
                        echo '<div class="updated" id="message" style="background-color: rgb(255, 251, 204);"><p><strong>You should enter a valid embed-code</strong></div>';
                }
                if($_POST['thumb'] == ''){
                        echo '<div class="updated" id="message" style="background-color: rgb(255, 251, 204);"><p><strong>You should enter a valid thumbnail URL</strong></div>';
                }
                if($_POST['title'] == ''){
                        echo '<div class="updated" id="message" style="background-color: rgb(255, 251, 204);"><p><strong>You should enter a title</strong></div>';
                }
	}
?>
<form name="post" method="post">
  <div class="wrap"><h3>Submit a New Video to Your Website</h3>
    <div id="poststuff">
      <div id="post-body">
        <div class="postbox"><h3>Video Title:</h3>
          <div class="inside">
            <input type="text" name="title" size="30" tabindex="1" value="<?php echo htmlspecialchars($_POST['title']);?>" id="title"  style="width: 98%;"/>
          </div>
        </div>
        <div class="postbox"><h3>Video Description:</h3>
          <div class="inside">
<textarea id="description" tabindex="6" name="description" cols="40" rows="2" style="width: 98%;"/>
<?php echo htmlspecialchars($_POST['description']);?>
</textarea>
          </div>
        </div>
        <div class="postbox"><h3>
            <label for="title">Video Category:
            </label></h3>
          <div class="inside">
            <?php wp_dropdown_categories( array( 'hide_empty' => 0, 'name' => 'category', 'orderby' => 'id', 'hierarchical' => 1, 'tab_index' => 3 ) ); ?>
          </div>
        </div>
        <div class="postbox"><h3>Tags: <small>seperated by comma's</small></h3>
          <div class="inside">
            <input type="text" name="tags" size="30" tabindex="1" value="<?php echo htmlspecialchars($_POST['tags']);?>" id="tags"  style="width: 98%;"/>
          </div>
        </div>
        <div class="postbox"><h3>Thumbnail URL: <small>To find out the URL of a thumbnail image right click on the thumbnail and scroll down to properties, the URL will be under location.</small></h3>
          <div class="inside">
            <input type="text" name="thumb" size="30" tabindex="1" value="<?php echo htmlspecialchars($_POST['thumb']);?>" id="thumb"  style="width: 98%;"/>
          </div>
        </div>
        <div class="postbox"><h3>Embed Code: <small>Remember to adjust the embed player size to match your theme!</small></h3>
          <div class="inside">
<textarea id="embed" tabindex="6" name="embed" cols="40" rows="2" style="width: 98%;"/>
<?php echo stripslashes(htmlspecialchars($_POST['embed']));?>
</textarea>
          </div>
        </div>
      </div>
    </div>
    <input type="hidden" name="submit" value="submit">
    <input type="submit" name="submit" value="Submit">
</form>
<?php
}
// start of jquery modal video popups
$lightwindow = 1;

if($lightwindow){

wp_register_script('jquery', get_bloginfo('wpurl') . '/wp-content/plugins/videoswiper/lightwindow/javascript/jquery-1.4.2.min.js'); // loads javascript library
wp_register_script('colorbox', get_bloginfo('wpurl') . '/wp-content/plugins/videoswiper/lightwindow/javascript/jquery.colorbox.js'); // loads jquery colorbox modal box

wp_enqueue_script('jquery'); // makes script unique no conflict
wp_enqueue_script('colorbox'); // makes script unique no conflict

add_action('wp_head', '_videoswiper_head_lightwindow'); // loads the javascript and css files into the wordpress header
}

function _videoswiper_head_lightwindow(){
	echo '<link type="text/css" rel="stylesheet" href="'.get_bloginfo('wpurl') . '/wp-content/plugins/videoswiper/lightwindow/css/colorbox.css'.'">'."\n";  // loads modal popup css
	echo '<link type="text/css" rel="stylesheet" href="'.get_bloginfo('wpurl') . '/wp-content/plugins/videoswiper/css/default.css'.'">'."\n"; // loads page css to keep the videos hidden
	echo '
<script type="text/javascript">
var $j = jQuery.noConflict();
$j(document).ready(function(){
$j(".gallery").colorbox({transition:"elastic", speed:500, scrolling:false, slideshow:false}); 
$j.fn.colorbox.resize();
});
</script>
';
}


function _videoswiper_filter_content($result){
	global $post;
	global $lightwindow;
$meta = get_post_custom();
if(isset($meta['videoswiper-embed-code']) and !is_single()) {
		preg_match('/width=[^\d]*(\d+)[^\d]*/s',stripslashes($meta['videoswiper-embed-code'][0]),$matches);
		$width = $matches[1];
		
		preg_match('/height=[^\d]*(\d+)[^\d]*/s',stripslashes($meta['videoswiper-embed-code'][0]),$matches);
		$height = $matches[1];
		$smarty_filtered_result = smarty_modifier_links($result);
	
	$tagshtml;
	$posttags = get_the_tags();
	$tagscount = 0;
	if ($posttags) {
		foreach($posttags as $tag) {
			$tagshtml .= '<a title="Tag | '.$tag->name.'" href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a>, ';
			$tagscount += strlen($tag->name)+2;
		}
	}
	$tagshtml = substr($tagshtml,0,strlen($tagshtml)-2);
    $content .= '<div class="video-processed-post">';
 		$content .= '<a title="'.$post->post_title.'" href="'.get_bloginfo('wpurl') . '/player.php?postID='.$post->ID.'" class="gallery">'; // link used for the video thumbnails to call modal popup
 		$content .= '
		<div class="video-thumbnail-container">
			<img src="'.get_bloginfo('wpurl') . '/'.$meta['videoswiper-embed-thumb'][0].'" class="video-thumbnail">
		 <span class="usernames_bg"><img style="vertical-align:middle;border:0;padding-left:5px;" src="'.get_bloginfo('wpurl') . '/wp-content/plugins/videoswiper/images/movie_15x15.png"> Quick View Player</span>
    </div>
	</a><div class="video-post-content-container">
	'.((strlen($smarty_filtered_result) > (350-$tagscount))?(substr($smarty_filtered_result,0,(350-$tagscount) - strlen(strrchr(substr($smarty_filtered_result,0,(350-$tagscount)),' '))).' <a href="'.get_permalink($post->ID).'"> (<B>View More....</B>)</a></p>'):$smarty_filtered_result).'
	<div style="padding-top:5px;" class="video-post-content-tags"><b>Video Tags:</b> '.$tagshtml.'</div>
  </div>
</div>
<div class="video-clear-both"></div>
'; // code above loads all the videos on page then hides them from view for modal popup to load
		return $content;
	}elseif(isset($meta['videoswiper-embed-code'])){
		$category = 0;
		foreach((get_the_category()) as $category) { 
			$category = $category->cat_ID; 
		}		
		#$my_query = new WP_Query();
		#$myposts = $my_query->get_posts('numberposts=80&offset=0&orderby=rand&category='.$category);
		$this_page = $post->ID;
		$myposts = get_posts('numberposts=80&offset=0&orderby=rand&category='.$category);
		$postshtmlcount = 0;
		 $postshtml .= '<br class="video-clear-both">
		<div class="main_content">
		<div align="center" style="border-top:1px solid #DDD;margin:10px;"><br /><h1>More Related Videos</h1>
     		<br style="clear:both;"><br />
		<table align="center" border="0" cellspacing="0" cellpadding="0"><tr>';
                foreach($myposts as $post){
                        $custom = get_post_custom($post->ID);
                        $thumb = $custom['videoswiper-embed-thumb'][0];
                        if($thumb and ($postshtmlcount < 16)){
                                $postshtmlcount++;
				if($postshtmlcount > 1 and $postshtmlcount % 4 == 1){
                			$postshtml .= '</tr><tr>';
				}
                                $postshtml .= '<td align="center" class="video-related-td"><a class="linkopacity" href="'.get_permalink($post->ID).'" title="'. get_the_title($post->ID).'"><img src="'.get_bloginfo('wpurl') . '/'.$thumb.'" style="margin:3px;border:5px solid #DDD;max-width:120px;max-height:90px;padding:2px;" alt="'.get_the_title($post->ID).'"></a>'.'</td>';
                        }
                }
                $postshtml .= '</tr></table></div></div>';
		$myposts = get_posts("post_type=post&include=".$this_page);
		foreach($myposts as $post){
			setup_postdata($post);
		}	
	
		return '<br><center>'.stripslashes($meta['videoswiper-embed-code'][0]).'</center><br>'.smarty_modifier_links($result).($postshtmlcount?$postshtml:'');
	}else{
		return $result;
	}
}
function smarty_modifier_links($string)
{
    $string = html_entity_decode($string);
	$string = str_replace('</a>', '', $string);
	$string = preg_replace('/<a[^>]+href[^>]+>/', '', $string);
	$string = " ".$string;
	$string = eregi_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)', '<a href="\\1" rel="nofollow" target="_blank">\\1</a>', $string);
	$string = eregi_replace('(((f|ht){1}tps://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)', '<a href="\\1" rel="nofollow" target="_blank">\\1</a>', $string);
	$string = eregi_replace('([[:space:]()[{}])(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)', '\\1<a href="http://\\2" rel="nofollow" target="_blank">\\2</a>', $string);
	$string = eregi_replace('([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})', '<a href="mailto:\\1" rel="nofollow" target="_blank">\\1</a>', $string);
	return $string;
}
?>