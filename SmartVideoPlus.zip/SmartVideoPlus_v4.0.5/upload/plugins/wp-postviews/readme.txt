=== WP-PostViews ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: views, hits, counter, postviews
Requires at least: 2.8
Stable tag: 1.50

Enables you to display how many times a post/page had been viewed.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-PostViews Readme](http://lesterchan.net/wordpress/readme/wp-postviews.html "WP-PostViews Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-PostViews Readme](http://lesterchan.net/wordpress/readme/wp-postviews.html "WP-PostViews Readme") (Installation Tab)

== Screenshots ==

[WP-PostViews Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-postviews/ "WP-PostViews Screenshots")

== Frequently Asked Questions ==

[WP-PostViews Support Forums](http://forums.lesterchan.net/index.php?board=16.0 "WP-PostViews Support Forums")