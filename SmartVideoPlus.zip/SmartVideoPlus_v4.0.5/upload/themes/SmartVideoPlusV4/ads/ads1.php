<!--Enter Your Own Ad Code Here-->
<div align="center"><a href="http://www.videoswiper.com/" title="VideoSwiper Video Application">
<img src="http://www.videoswiper.com/banners/vs_468x60.gif" width="468" height="60" border="0"></a>
</div>
<!--Enter Your Own Ad Code Here-->