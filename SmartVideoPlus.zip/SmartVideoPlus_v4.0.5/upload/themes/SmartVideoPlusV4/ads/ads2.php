<!--Enter Your Own Ad Code Here-->
<div align="center"><a href="http://www.videoswiper.com/" title="VideoSwiper Video Application">
<img src="http://www.videoswiper.com/banners/vs_728x90.gif" width="728" height="90" border="0"></a></div>
<!--Enter Your Own Ad Code Here-->