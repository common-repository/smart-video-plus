<!--Enter Your Own Ad Code Here-->
<div align="center"><a href="http://www.videoswiper.com/" title="VideoSwiper Video Application">
<img src="http://www.videoswiper.com/banners/vs_300x250.gif" width="300" height="250" border="0"></a></div>
<!--Enter Your Own Ad Code Here-->