<!--Enter Your Own Sponsored Links Below Following The Same <li></li> Structure-->
<li><a title="VideoSwiper Video Application" href="http://www.videoswiper.com">Bulk Add Videos Directly to Your Wordpress</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>
<li><a title="" href="#">Advertise Your Website Here (Contact us)</a></li>