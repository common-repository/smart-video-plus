<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
			?>

			<p>This post is password protected. Enter the password to view comments.</p>

			<?php
			return;
		}
	}

?>
<!-- You can start editing here. -->
<?php if ($comments) : ?>
	<h5 id="comments"><?php comments_number('No Responses', 'One Response', '% Responses' );?> to &#8220;<?php the_title(); ?>&#8221;</h3>
	<ol>
	<?php foreach ($comments as $comment) : ?>
<fieldset class="form_boxv2">
		<li id="comment-<?php comment_ID() ?>">
			<cite><?php comment_author_link() ?></cite> Says:
			<?php if ($comment->comment_approved == '0') : ?>
			<em>Your comment is awaiting moderation.</em>
			<?php endif; ?>
			<br />
			<small><a href="#comment-<?php comment_ID() ?>" title=""><?php comment_date('F jS, Y') ?> at <?php comment_time() ?></a> <?php edit_comment_link('edit','&nbsp;&nbsp;',''); ?></small>
			<?php comment_text() ?>
		</li>
</fieldset>
	<?php endforeach; /* end for each comment */ ?>
	</ol>
</div>
</div>	
 <?php else : // this is displayed if there are no comments so far ?>
<?php if ('open' == $post->comment_status) : ?>
<div class="error">Sorry there are no comments for this page / post so far! Why not be the first to add one</div>
</div>
</div>
<?php else : // comments are closed ?>
		<!-- If comments are closed. -->
		<div class="error">Sorry Comments for this page / post are closed.</div>
	<?php endif; ?>
<?php endif; ?>

<?php if ('open' == $post->comment_status) : ?>
<div class="content_main">
   <div class="titlev2"><span>
<?php if ( get_option('comment_registration') && !$user_ID ) : ?> 
You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>">logged in</a> to post a comment.
<?php else : ?></span>Leave a Reply</div>
<div class="content_padding">
<br />
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
<?php if ( $user_ID ) : ?><div style="float:right;padding:10px;">Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="Log out of this account">Logout &raquo;</a></div>
<?php else : ?>
<label style="float:left;width:150px;text-align:right;padding-top:5px;padding-right:3px;" for="author">Name: <?php if ($req) echo "(required)"; ?></label>
<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
<br /><br />
<label style="float:left;width:150px;text-align:right;padding-top:5px;padding-right:3px;" for="email">EMail: <?php if ($req) echo "(required)"; ?></label>
<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
<br /><br />
<label style="float:left;width:150px;text-align:right;padding-top:5px;padding-right:3px;" for="url">Website:</label>
<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
<br />
<?php endif; ?>

<!--<p><small><strong>XHTML:</strong> You can use these tags: <code><?php echo allowed_tags(); ?></code></small></p>-->
<div style="float:left;padding-left:10px;padding-top:10px;">
<textarea name="comment" id="comment" style="width:575px;height:100px;padding:5px;" tabindex="4"></textarea>
</div>
<div style="clear:both;"></div>
<div style="float:left;padding-left:10px;">
<input name="submit" type="submit" class="button" id="submit" tabindex="5" value="Submit Comment" />
<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
</div>
<?php do_action('comment_form', $post->ID); ?>

</form>

<?php endif; // If registration required and not logged in ?>
<?php endif; // if you delete this the sky will fall on your head ?>