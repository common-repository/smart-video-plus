<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<meta property="og:type" content="Website" />
<meta property="fb:app_id" content="161641817188327"/> <!--HERE YOU NEED TO ADD YOUR OWN FACEBOOK APPLICATION ID-->
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/js/jquery-tabber.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/js/ddsmoothmenu.css" type="text/css" media="screen"/>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<script type="text/javascript" language="javascript" src="<?php bloginfo('template_url'); ?>/js/ddsmoothmenu.js"></script>
<script type="text/javascript" language="javascript" src="<?php bloginfo('template_url'); ?>/js/menu.js"></script>
<script type="text/javascript" language="javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-tabber.js"></script>
<script type="text/javascript" language="JavaScript" src="<?php bloginfo('template_url'); ?>/js/crawler.js"></script>

<script language="JavaScript" type="text/javascript">
var $j = jQuery.noConflict();
$j(function() {
		$j( "#tabs" ).tabs();
		$j( "#tabs_sidebar_1" ).tabs();
		$j( "#tabs_sidebar_2" ).tabs();
});
</script>
</head>
<body>
<div id="wrapper_sec">
	<div id="masthead">
    	<div class="inner">
    	            <div class="logo"><h1><a title="<?php bloginfo('name'); ?>" href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a></h1>
                  <p><?php bloginfo('description'); ?></p>
                  </div>
            <div class="search">
            	<ul class="topbtns">
                  <li><script type="text/javascript" language="javascript" src="<?php bloginfo('template_url'); ?>/js/date.js"></script></li>
                </ul>            
                <ul class="searchsec">        
                    <li>
                    <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/" style="margin:0px; padding:0px;"> 
                    <input type="text" name="s" id="s" class="bar" value='<?php the_search_query(); ?>'/></li>
                    <li><input type="hidden" name="submit"/><input class="search_btn" type="image" name="submit" src="<?php bloginfo('template_directory'); ?>/images/go.gif" alt="Search" /></form></li>
                </ul>
            </div>
<div class="clear"></div>
  <div class="navigation">
     <div id="smoothmenu1" class="ddsmoothmenu">
<ul>
<li><a href="<?php echo get_option('home'); ?>/" class="on">Home</a></li>
<?php wp_list_pages('depth=10&title_li='); ?>
</ul>
<br style="clear:left"/>
  </div>
 </div>
</div>
    </div>
<div id="content_sec">
        <div class="rec_news">
        	<h5>What's New!</h5>
           <div class="rec_news_text"><?php include (TEMPLATEPATH . '/page_effects/news_ticker.php'); ?></div>
            <ul class="networks">
            	<li><?php include (TEMPLATEPATH . '/facebook_twitter/twitter_user.php'); ?><img border="0" src="<?php bloginfo('template_directory'); ?>/images/twitter_head.png" alt="Follow on Twitter"/></a> <?php include (TEMPLATEPATH . '/facebook_twitter/facebook_user.php'); ?><img border="0" src="<?php bloginfo('template_directory'); ?>/images/facebook_head.png" alt="Follow us on Facebook"/></a> <a title="Follow us Via RRS Feeds" href="<?php bloginfo('rss2_url'); ?>"><img border="0" src="<?php bloginfo('template_directory'); ?>/images/rss_head.png" alt="Follow us Via RRS Feeds"/></a></li>
            </ul>
        </div>
<!--end header-->
