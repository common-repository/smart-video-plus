<?php get_header();?>

<div class="contents">
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads2.php'); ?>
</div>
<br />
<div class="col1">
<div class="content_main">
<div class="titlev2">Videos Watching Now!</div>
<div class="content_padding">
<div class="flash_scroller">
<div align="left">
<object type="application/x-shockwave-flash" data="<?php bloginfo('template_url'); ?>/recentplayer.swf"   width="605" height="110" id="slideshow" align="middle">
<param name="movie" value="<?php bloginfo('template_url'); ?>/recentplayer.swf" />
<param name="allowScriptAccess" value="sameDomain" />
<param name="FlashVars" value="<?php
$myposts = get_posts('numberposts=10&offset=0&orderby=date');
$postshtmlcount = 0;
foreach($myposts as $post){
$custom = get_post_custom($post->ID);
$thumb = $custom['videoswiper-embed-thumb'][0];
if($thumb and ($postshtmlcount < 11)){
$postshtmlcount++;
                        if(!strstr($thumb,'http://')){
                            $thumb = get_bloginfo('wpurl') . $custom['videoswiper-embed-thumb'][0];
                        }

			echo 'image'.$postshtmlcount.'='.$thumb.'&texto'.$postshtmlcount.'='.get_the_title($post->ID).'&url'.$postshtmlcount.'='.get_permalink($post->ID).'/&';

		}
	}
?>"/>
<param name="quality" value="high" /><param name="wmode" value="transparent" />
</object>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/FlashFix.js"></script>
</div>
</div>
</div>
</div>
<div class="content_main_no_border">
<div id="tabs" style="width:618px;">      
      <ul>
       <li><a href="#tabs-1">Videos Basic View</a></li>
       <li><a href="#tabs-2">Videos List View</a></li>
       <li><a href="#tabs-3">Follow us</a></li>
       <li><a href="#tabs-4">Contact Us</a></li>
    </ul>  
<div id="tabs-1">
<br />
<?php
			if (have_posts()) : ?>
			<div style="padding-left:10px;" id="videos">
			<?php $i=0; while (have_posts()) : the_post(); $i++; ?>
				<!-- post -->
				<div class="video<?php if($i%4==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
				<div class="thumbsf_index"> 
                                    <a class="gallery" title="<?php the_title_attribute(); ?>" href="<?php bloginfo('url'); ?>/player.php?postID=<?php the_ID(); ?>"><?php $thumb = thman_getcustomfield('videoswiper-embed-thumb',get_the_ID()); if(!empty($thumb)) { if(!strstr($thumb,"http://")){ $thumb = get_bloginfo('url').$thumb; } ?><img style="width:120px;height:90px;" src="<?php echo $thumb; ?>" alt="<?php the_title_attribute(); ?>" />
           <?php }else { ?><img style="width:120px;height:90px;" src="<?php bloginfo('template_url'); ?>/images/no_image.gif" alt="<?php the_title_attribute(); ?>" /></a><?php } ?>
           <span class="username_bg"><img style="vertical-align:middle;border:0;padding-left:5px;" src="<?php bloginfo('template_url'); ?>/images/movie_15x15.png"> Quick View Player</span>
             </div></a><!--VID_THUMB END-->
					<div class="info">
						<div style="padding-top:5px;" class="info_left">
						<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,10); ?></a></h2>
							<?php if(function_exists('the_views')) {  ?><p class="views">Total: <?php the_views(); ?></p><?php } ?>
							<p class="views">(<?php comments_popup_link('0', '1', '%'); ?>) Comment(s)</p>
					     </p>
						</div>
          </div>
				</div>
				<?php if($i%4==0) : ?><div class="clear"></div>
        <?php endif; ?>
				<!-- /post -->
			<?php endwhile; ?>
			</div>
			<?php 
			$next_page = get_next_posts_link('Previous'); 
			$prev_pages = get_previous_posts_link('Next');
			if(!empty($next_page) || !empty($prev_pages)) :
			?>
			<!-- navigation -->
			<div style="clear:both;"></div>
			<div style="text-align:right;padding-top:10px;padding-bottom:10px;padding-right:10px;">
				<?php if(!function_exists('wp_pagenavi')) : ?>
				<div class="alignleft"><?php echo $next_page; ?></div>
				<div class="alignright"><?php echo $prev_pages; ?></div>
				<?php else : wp_pagenavi(); endif; ?>
				<div style="clear:both;"></div>
			</div>
			<!-- /navigation -->
			<?php endif; ?>
		<?php 
		else :	?><div class="error">Sorry, but you are looking for something that isn't here.</div>
      <?php include (TEMPLATEPATH . "/searchform.php"); ?>
      <?php	endif;?>
</div>
<div id="tabs-2">
 <?php			
			if (have_posts()) : ?>
			<div style="padding-left:5px;" id="videos">
			<?php $i=0; while (have_posts()) : the_post(); $i++; 
                        ?>

				<!-- post -->			
        <div class="video_wide<?php if($i%1==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
					<fieldset style="width:595px;" class="form_boxv2">
          <h2><span style="float:right;width:150px;font-size:14px;"><?php the_time('F jS, Y') ?></span>
          <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,50); ?></a></h2>				
					<div class="info">
					<?php 

                                        // echo get_the_content();
                                        ob_start();
                                        the_content('Read the rest of this entry &raquo;');
                                        $contents = ob_get_contents();
                                        ob_end_clean();
                                        //echo $contents;
                                        echo preg_replace('/"http.[^"]*?(http.*?)"/','"$1"',$contents);
                                         ?>
          </div>       
				</div>
				</fieldset>
				<div class="more_info">
        <?php if(function_exists('the_views')) {  ?>Total: <?php the_views(); ?><?php } ?> | <span class="comments"><?php comments_popup_link('0', '1', '%'); ?> </span> | <span class="category"><?php the_category(', ') ?></span>
         <span class="bookmark">
<table cellspacing="0" cellpadding="0" width="100%">
<tr>
<td align="right"><a rel="nofollow" href="http://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="none" data-via="wordpress">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></td>
<td align="right"><a rel="nofollow" title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-button"></a>
<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script></td>
</tr>
</table>
    </span>
         </div>
				<?php if($i%1==0) : ?>
           <?php endif; ?>
              <div style="clear:both;"></div>
				<!-- /post -->
			<?php endwhile; ?>
			</div>
			<?php 
			$next_page = get_next_posts_link('Previous'); 
			$prev_pages = get_previous_posts_link('Next');
			if(!empty($next_page) || !empty($prev_pages)) :
			?>
			<!-- navigation -->
			<div style="clear:both;"></div>
		<div style="text-align:right;margin-top:20px;padding-bottom:10px;padding-right:10px;">
				<?php if(!function_exists('wp_pagenavi')) : ?>
				<div class="alignleft"><?php echo $next_page; ?></div>
				<div class="alignright"><?php echo $prev_pages; ?></div>
				<?php else : wp_pagenavi(); endif; ?>
			</div>
			<!-- /navigation -->
			<?php endif; ?>
		<?php 
		else : ?><div class="error">Sorry, but you are looking for something that isn't here.</div>
      <?php include (TEMPLATEPATH . "/searchform.php"); ?>
      <?php	endif;?> 
    </div>
<div id="tabs-3">
<br />    
<div id="tweet">
 <p>Please wait while my tweets load <img src="<?php bloginfo('template_directory'); ?>/images/ajax-loader.gif" /></p>
</div>
</div>
<div id="tabs-4">
<br />
<?php if (function_exists (gCF)) gCF(); ?>
</div>   
</div>
</div>
	<!-- /content -->
<!--// page end //-->
</div>
<?php get_sidebar(); ?>
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads5.php'); ?>
</div></div>
<?php get_footer(); ?>