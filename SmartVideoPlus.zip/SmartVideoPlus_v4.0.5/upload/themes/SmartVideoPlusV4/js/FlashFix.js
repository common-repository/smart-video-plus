JavaScript:

function writeFlash(id) {
    document.getElementById(id).innerHTML = "<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0' width='200' height='200' id='myflash' align='middle'><param name='allowScriptAccess' value='sameDomain' /><param name='movie' value='mymovie.swf' /><param name='quality' value='high' /><param name='bgcolor' value='#ffffff' /><embed src='mymovie.swf' quality='high' bgcolor='#ffffff' width='200' height='200' name='mymovie' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer' /></object>";
} 