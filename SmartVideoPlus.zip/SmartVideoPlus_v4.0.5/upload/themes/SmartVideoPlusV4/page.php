<?php get_header(); ?>
<div class="contents">
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads2.php'); ?>
</div>
<br />
<div class="col1">
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<div class="content_main">
<div class="titlev2"><span><?php if(function_exists('the_views')) {  ?>Total Views: <?php the_views(); ?><?php } ?></span><?php the_title(); ?></div>
<div class="content_padding">
<div style="font-size:14px;line-height:18px;" class="post" id="post-<?php the_ID(); ?>">
<?php the_content('More &raquo;'); ?></div>
<div class="subcontrol">	
  <table cellspacing="0" cellpadding="0" width="100%">
<tr>
<td align="left"><script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like href="<?php the_permalink() ?>" font="arial"></fb:like></td>
<td align="right"><a rel="nofollow" href="http://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="none" data-via="wordpress">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></td>
<td align="right"><a rel="nofollow" title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-button"></a>
<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script></td>
</tr>
</table>
</div>
	</div>
</div>
<div class="content_main">
   <div class="titlev2">Advertisement</div>
	<div class="content_padding">
<?php include (TEMPLATEPATH . '/ads/ads1.php'); ?>
</div>
	</div>
<div class="content_main">
   <div class="titlev2"><span><img style="vertical-align:middle;" src="<?php bloginfo('template_directory'); ?>/images/rss.png" border="0"> <?php comments_rss_link('Follow Discussion'); ?></span>Comments</div>
	<div class="content_padding">
	<?php comments_template(); ?>
	</div>
	</div>
<?php endwhile; ?>

<div class="navigation">
<div class="alignleft"><?php next_posts_link('&laquo; Older Posts') ?></div>
<div class="alignright"><?php previous_posts_link('Newer Posts &raquo;') ?></div>
</div>

<?php else : ?>
<div class="content_main">
   <div class="titlev2">System Error</div>
	<div class="content_padding">
<div class="error">Sorry but you are looking for something that isn't here.</div>
<?php include (TEMPLATEPATH . "/searchform.php"); ?>
</div>
	</div>
<?php endif; ?>
<div class="content_main">
   <div class="titlev2">Advertisement</div>
	<div class="content_padding">
<?php include (TEMPLATEPATH . '/ads/ads7.php'); ?>
</div>
	</div>
</div>
<?php get_sidebar(); ?>
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads5.php'); ?>
</div>
<?php get_footer(); ?>
