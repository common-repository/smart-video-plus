<div class="marquee" id="mycrawler">&nbsp;&nbsp;&nbsp;&nbsp;.
<!--START CONTENT-->
&nbsp;&nbsp;&nbsp;&nbsp;<!--content 1-->Natoque justo nibh eros est natoque montes tellus ut id Aliquam. Orci nunc mauris eget pharetra tincidunt nunc Donec pretium et nonummy. Nunc id justo Nulla sit pretium elit id quis pulvinar consectetuer. Eget nunc cursus tincidunt Vestibulum Pellentesque pharetra Nulla in id Pellentesque. Iaculis mattis quis tristique odio auctor volutpat nec Nulla urna.
&nbsp;&nbsp;&nbsp;&nbsp;<!--content 2-->Lorem ipsum dolor sit amet consectetuer mi dui risus fames laoreet. Curabitur Morbi In cursus aliquam eget justo nonummy id Vestibulum et. Mauris dapibus pede tellus nibh metus sagittis nec mollis Vestibulum felis. Enim Aenean vitae augue pede leo quis leo nibh facilisis Vestibulum. Tortor dolor lobortis Phasellus augue amet et wisi et Nulla adipiscing. Elit amet ut nisl urna gravida Lorem ac.
&nbsp;&nbsp;&nbsp;&nbsp;<!--content 3-->Nam volutpat nunc Morbi morbi auctor nibh purus molestie ridiculus Morbi. Massa est lacus velit ligula senectus sapien vitae felis ligula amet. Mauris orci dictumst leo semper nec Aenean
&nbsp;&nbsp;&nbsp;&nbsp;<!--content 4-->Natoque justo nibh eros est natoque montes tellus ut id Aliquam. Orci nunc mauris eget pharetra tincidunt nunc Donec pretium et nonummy. Nunc id justo Nulla sit pretium elit id quis pulvinar consectetuer.
<!--END CONTENT-->
&nbsp;&nbsp;&nbsp;&nbsp;</div>
<!--DO NOT EDIT BELOW THIS LINE-->
<script type="text/javascript">
marqueeInit({
	uniqueid: 'mycrawler',
	style: {
		'padding': '0px',
		'margin': '0px',
		'width': '700px',
		'background': 'transparent',
		'color': '#2573cf',
		'font-weight': 'normal',
		'font-family': 'Verdana',
		'font-size': '12px',
		'border': '0px'
	},
	 inc: 1,
	 mouse: 'cursor driven',
	 moveatleast: 1,
   noAddedSpace: true,
   neutral: 150,
	 savedirection: true
});
</script>