<?php get_header(); ?>

<div class="contents">
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads2.php'); ?>
</div>
<br />
<div class="col1">
<div class="content_main">
<div class="titlev2">Search Results</div>
<div class="content_padding">
<?php if (have_posts()) : ?>
			<div id="videos">
			<?php $i=0; while (have_posts()) : the_post(); $i++; ?>
				<!-- post -->
				<div class="video_wide<?php if($i%1==0) : ?> video_last<?php endif; ?>" id="video-<?php the_ID(); ?>">
					<fieldset style="width:580px;" class="form_boxv2">
          <h2><span style="float:right;width:150px;">
          </span><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo thman_get_limited_string($post->post_title,50); ?></a></h2>
				
					<div class="info">
					<?php ob_start();
                                        the_content('Read the rest of this entry &raquo;');
                                        $contents = ob_get_contents();
                                        ob_end_clean();
                                        //echo $contents;
                                        echo preg_replace('/"http.[^"]*?(http.*?)"/','"$1"',$contents);
                                        ?>
          </div>       
				</div>
				</fieldset>
				<div class="more_info">
         <span class="date"><?php the_time('F jS, Y') ?></span> | <span class="comments"><?php comments_popup_link('0', '1', '%'); ?> </span> | <span class="category"><?php the_category(', ') ?></span>
                  <span class="bookmark">
<table cellspacing="0" cellpadding="0" width="100%">
<tr>
<td align="right"><a rel="nofollow" href="http://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="none" data-via="wordpress">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></td>
<td align="right"><a rel="nofollow" title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-button"></a>
<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script></td>
</tr>
</table>
         </span>
         </div>
				<?php if($i%1==0) : ?><div class="clear"></div><?php endif; ?>
				<!-- /post -->
			<?php endwhile; ?>
			</div>
			<?php 
			$next_page = get_next_posts_link('Previous'); 
			$prev_pages = get_previous_posts_link('Next');
			if(!empty($next_page) || !empty($prev_pages)) :
			?>
			<!-- navigation -->
			<div style="clear:both;"></div>
			<div style="text-align:right;margin-top:10px;padding-bottom:10px;padding-right:10px;">
				<?php if(!function_exists('wp_pagenavi')) : ?>
				<div class="alignleft"><?php echo $next_page; ?></div>
				<div class="alignright"><?php echo $prev_pages; ?></div>
				<?php else : wp_pagenavi(); endif; ?>
			</div>
			<!-- /navigation -->
			<?php endif; ?>
		<?php else :?><div class="error">Sorry, but you are looking for something that isn't here.</div>
    <?php include (TEMPLATEPATH . "/searchform.php"); ?>
    <?php endif;?>    
<div class="clear"></div>
</div>
</div>
<!--// page end //-->
</div>
<?php get_sidebar(); ?>
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads5.php'); ?>
</div>
<?php get_footer(); ?>