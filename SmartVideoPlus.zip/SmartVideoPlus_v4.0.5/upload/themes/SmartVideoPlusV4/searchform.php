<div style="margin-top:20px;" align="center">
<h1>Start Search Again!</h1>
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><input type="text" class="text" value="<?php the_search_query(); ?>" name="s" id="s" />
<input type="submit" class="button" id="searchsubmit" value="Search" />
</div>
</form>
</div>