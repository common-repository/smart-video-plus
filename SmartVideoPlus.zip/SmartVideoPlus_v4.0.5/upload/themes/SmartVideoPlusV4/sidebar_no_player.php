<div class="col2">

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>

<div class="content_sidebar">
<div class="titlev2">Advertisement</div>
<div class="content_padding">
<?php include (TEMPLATEPATH . '/ads/ads3.php'); ?>
</div>
</div>

<div class="content_sidebar_blank">
<div style="width:305px;" id="tabs_sidebar_1">      
      <ul>
       <li><a href="#tabs-5"><?php _e('Video Channels'); ?></a></li>
       <li><a href="#tabs-6"><?php _e('Video Archives'); ?></a></li>
    </ul>  
<div id="tabs-5">
<br />
<ul class="tabbertab">
	<?php wp_list_cats('sort_column=name&hierarchical=0'); ?>
	</ul>
</div>	
<div id="tabs-6">
<br />
<ul class="tabbertab">
	<?php wp_get_archives('type=monthly'); ?>
	</ul>
	</div>
</div>
</div>

<div class="content_sidebar">
<div class="titlev2">Advertisement</div>
<div class="content_padding">
<?php include (TEMPLATEPATH . '/ads/ads4.php'); ?>
</div>
</div>

<div class="content_sidebar_blank">
<div style="width:305px;" id="tabs_sidebar_2">      
      <ul>
       <li><a href="#tabs-7">Links</a></li>
       <li><a href="#tabs-8">Pages</a></li>
       <li><a href="#tabs-9">RSS Feeds</a></li>
    </ul>  
<div id="tabs-7">
<br />
<ul>
	<?php get_links(2, '<li>', '</li>', '', TRUE, 'url', FALSE); ?>	
	</ul>
</div>	
<div id="tabs-8">
<br />
	<ul>
	<?php wp_list_pages('title_li='); ?>
	</ul>
	</div>
<div id="tabs-9">
<br />
<ul>
	 <li><a href="<?php bloginfo('rss2_url'); ?>" title="RSS Feeds">Latest 10 RSS Video Feeds</a></li>
	 <li><a href="<?php echo get_settings('home'); ?>/comments/feed/" title="RSS Feeds">Latest 10 RSS Comments</a></li>  
  </ul>
	</div>
</div>
</div>

<?php endif; ?>  
<!--// page end //-->
</div>
