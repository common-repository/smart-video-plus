<?php get_header(); ?>
<div class="contents">
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads2.php'); ?>
</div>
<br />
<div class="col1">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="content_main">
   <div class="titlev2" id="post-<?php the_ID(); ?>"><span class="cat">Added By: <?php the_author() ?></span><a href="<?php echo get_permalink() ?>" rel="bookmark" title="Video: <?php the_title_attribute(); ?>"><?php the_title(); ?></a></div>
<div class="content_padding">
<?php 
//the_content();
ob_start();
the_content();
$contents = ob_get_contents();
ob_end_clean();
//echo $contents;
echo preg_replace('/"http.[^"]*?(http.*?)"/','"$1"',$contents);
?>
</div>
</div>

<div class="content_main">
<div class="titlev2">Video Details</div>
	<div class="content_padding">
<div class="allinfos">
	<span class="date"><?php the_time('F jS, Y') ?></span> | <span class="comments"><?php comments_number('0', '1', '%'); ?></a> </span> | <span class="category"><?php the_category(', ') ?></span> | <?php if(function_exists('the_views')) {  ?> Total Views: <?php the_views(); ?><?php } ?></div>
</div>
</div>

<div class="content_main">
<div class="titlev2">Share</div>
	<div class="content_padding">
<div class="allinfos">
  <table cellspacing="0" cellpadding="0" width="100%">
<tr>
<td align="left"><script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like href="<?php the_permalink() ?>" font="arial"></fb:like></td>
<td align="right"><a rel="nofollow" href="http://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="none" data-via="wordpress">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></td>
<td align="right"><a rel="nofollow" title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-button"></a>
<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script></td>
</tr>
</table>	
  </div>
</div>
</div>

<div class="content_main">
<div class="titlev2">Advertisement</div>
<div class="content_padding">
<?php include (TEMPLATEPATH . '/ads/ads7.php'); ?>
</div>
</div>	

<div class="content_main">
   <div class="titlev2"><span><img style="vertical-align:middle;" src="<?php bloginfo('template_directory'); ?>/images/rss.png" border="0"> <?php comments_rss_link('Follow Discussion'); ?></span>Comments</div>
	<div class="content_padding">
	<?php comments_template(); ?>
	</div>
	</div>

<?php endwhile; else: ?>

<div class="entry">
<div class="error"><b>Sorry</b>, no posts matched your criteria.</div>
</div>

<?php endif; ?>

</div>

<?php include (TEMPLATEPATH . '/sidebar_no_player.php'); ?>
<div align="center">
<?php include (TEMPLATEPATH . '/ads/ads5.php'); ?>
</div>
<?php get_footer(); ?>
