<script src="http://twitterjs.googlecode.com/svn/trunk/src/twitter.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8">
getTwitters('tweet', { 
  id: 'cnn', // change the name between the '' to your own twitter username.
  count: 50, // here you can change the amount of twitter tweets that are displayed.
    
  //do not change below this line 
 
  enableLinks: true, //do not change
  ignoreReplies: true, //do not change
  clearContents: true, //do not change
  template: '<table style="margin-bottom:5px;background:#eee;border-top:1px solid #ddd;border-bottom:1px solid #ddd;width:99%;" cellpadding="5" cellspacing="0"><tr><td width="60px" align="left"><a href="http://twitter.com/%user_screen_name%/statuses/%id%/"><img style="margin-bottom:5px;margin-top:5px;margin-left:5px;" src="%user_profile_image_url%"></td><td style="padding-left:5px;padding-right:10px;padding-top:5px;color:#000;" valign="top">%text%<br /><a href="http://twitter.com/%user_screen_name%/statuses/%id%/">%time%</a></td></tr></table>'
});
</script>
