<?php
/** ************************************************************************************************
  | Software Name        : VideoSwiper plugin
  | Version              : Smartvideoplusu
  | Software Author      : VideoSwiper  Team
  | Website              : http://www.videoswiper.com
  | E-mail               : support@videoswiper.com
  |**************************************************************************************************
  |
  |**************************************************************************************************
  | Please upload/place the file in the root folder where your script is installed and setup your
  | account at videoswiper.com .
  |**************************************************************************************************
  | Copyright (c) 2009-2010 videoswiper.com. All rights reserved.
  |************************************************************************************************* */

/* Dynamic Config */

$apiUsers = "";

/* No Editing below this line */

define('_NL',"\n");
define('_TIME',time());
define('_MYSQL_TIME',date('Y-m-d H:i:s',_TIME));
define('VSPLUS','http://www.videoswiperplus.com/api2/');

$ffmpeg = '/usr/bin/ffmpeg';
if(!is_file($ffmpeg))$ffmpeg = '/usr/local/bin/ffmpeg';

$php = '/usr/bin/php';
if(!is_file($php))$php = '/usr/local/bin/php';


class vsmod
{
    var $lastError = false;
    var $lastQuery = false;
    var $dbLink    = false;
    var $post = array();
    var $action = false;
    var $server = false;
    var $database = false;

    /* Script specefic settings */

    var $cConfig = "includes/config.php";
    var $cPaths = array();
    var $cDataBase = array('host'=>'host','username'=>'username','password'=>'password','database'=>'database','prefix'=>'','extract'=>'');
    
    var $cPrefix = '';

    var $cUserField = 'id';
    var $cUserTable = 'users';
    var $cUserConditions = "username = %s AND password = %s";

    var $cCategoryFields = 'id,name';
    var $cCategoryTable = 'categories';
    var $cCategoryConditions = "";

    var $cVideoEmbed = true;
    var $cVideoDownload = true;
    var $cVideoDownloadHD = true;
    /* video common */

    var $cImageTemp = false;
    var $cImageWidth = 160;
    var $cImageHeight = 120;

    var $cVideoField = 'id';
    var $cVideoFile = false;
    var $cVideoFilePath = false;
    var $cMp4File = false;
    var $cMp4FilePath = false;
    var $cMp4Only     = false;
    var $cVideoTable = "videos";
    var $cVideoVarMap = false; //  assc array
    var $cVideoUpdateVarMap = false;
    var $cVideoThumbs = false; // Default thumbs array

    var $cSeprator = '-';

    /* server */

    var $cServerField = 'id';
    var $cServerTable = 'servers';
    var $cServerConditions = "";
    var $cServerVarMap = false;
    var $cServerUpdateVarMap = false;

    /* constructor */

    function vsmod()
    {
        // get post variables

        foreach ($_POST as $var=>$val)
        {
            $this->post[$var] = stripslashes($val);
        }

        // Initialize the database

        $this->initDB();
    }

    /** some common functions */

    function path($relativePath)
    {
        //return dirname(__FILE__).'/'.$relativePath;
        return $relativePath;
    }

    function response($payload,$success = true)
    {

        $xmlFormat = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n<rsp stat=\"%s\">\n%s\n</rsp>";

        if ($success)
        {
            $response = sprintf($xmlFormat,'ok',$payload);
        }
        else
        {
            $response  = sprintf($xmlFormat,'fail','<err msg="'.$payload.'" detail="'.$this->lastError.'" />');
        }

        header("Content-type: application/xml");
        echo $response;
        die();
    }

    function getField($field,$table,$conditions) {

        $result = $this->query("SELECT $field FROM {$this->cPrefix}$table WHERE $conditions");

        $rowCount = mysql_num_rows($result);

        if ($rowCount) {
            $row = mysql_fetch_array($result);
            return $row[$field];
        }

        return false;

    }

    function valReplace($input)
    {
        extract($this->post);

        if (preg_match_all('%{\$([a-zA-Z0-9_.]+)}%',$input,$omatches))
        {
            $matches = array_unique($omatches[1]);

            $replaces = array();
            foreach ($matches as $match)
            {
                $replace = '';
                if(strstr($match,'.'))
                {
                    list($r_array,$r_index) = explode('.',$match);

                    $r_array = $$r_array;
                    $replace = isset($r_array[$r_index])?$r_array[$r_index]:$replace;

                } else {
                    $replace = isset(${$match})?${$match}:$replace;
                }

                $replaces[] = $replace;
            }

            $input = str_replace(array_unique($omatches[0]),$replaces,$input);
        }

        return $input;
    }

    function safeURL($title)
    {
        $title = strtolower($title);
        $title = preg_replace('/[^'.$this->cSeprator.'a-z0-9\s]+/', '', $title);
        $title = preg_replace('/['.$this->cSeprator.'\s]+/', $this->cSeprator, $title);

        return trim($title, $this->cSeprator);
    }

    function safeEncode($string)
    {
        $string = base64_encode($string);
        return str_replace(array('/','+','='),array('_','-',''),$string);
    }

    function safeDecode($string)
    {
    $string = str_replace(array('_','-'),array('/','+'),$string);
    return base64_decode($string);
    }

    function qs($value)
    {
        if (get_magic_quotes_gpc()) {
            $value = stripslashes($value);
        }

        return "'" . mysql_real_escape_string($value) . "'";
    }

    /**
     * Execute a mysql query on established connection
     *
     * @param string $query
     * @return MySql result
     */

    function query($query)
    {
        $this->initDB();
        $this->lastQuery = $query;
        $result = mysql_query($query,$this->dbLink);

        if(!$result){
            $this->response('MySQL Error executing '.$query.' : '.mysql_error(),false);
        }

        return $result;
    }

    function varMap($varMap)
    {
        $qMap = array();

        foreach ($varMap as $var=>$val)
        {
            $qName  =  preg_replace('/[^A-Za-z0-9_]+/', '', $var);
            if($var[0] == '#') {
                $qValue =  $this->qs($this->valReplace($val)); // standard define
            }
            else if($var[0] == '@') {
                $qValue =  $this->valReplace($val);
            }
            else {
                $qValue =  $this->qs($this->post[$val]);
            }
            $qMap[$qName] = $qValue;
        }

        return $qMap;


    }

    function queryCreate($table,$varMap)
    {

        $qMap = $this->varMap($varMap);

        $qNames  = implode(',',  array_keys($qMap));
        $qValues = implode(',',  array_values($qMap));

        $sql = "INSERT INTO {$this->cPrefix}$table ($qNames) VALUES ($qValues)";

        return $this->query($sql);

    }
    
    function queryUpdate($table,$varMap,$conditions)
    {
        $qMap = $this->varMap($varMap);

        $setArray = array();
        foreach ($qMap as $var=>$val)
        {
            $setArray[] = $var."=".$val;
        }

        $setString = implode(',',$setArray);

        $sql = "UPDATE {$this->cPrefix}$table SET $setString WHERE $conditions";

        return $this->query($sql);
    }

    function getRemoteFileSize($url)
    {
	    ob_start();
	    $ch = curl_init($url);
	    curl_setopt($ch, CURLOPT_HEADER, 1);
	    curl_setopt($ch, CURLOPT_NOBODY, 1);

             if(preg_match('/([a-z0-9]+)\.com/',$url,$match))
            {
                $name = $match[1];
                $cookieFile = $this->path($this->valReplace($this->cVideoFile));
                $cookieFile = dirname($cookieFile).'/'.$name.'.cookie';
                curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
                curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
            }

	    $ok = curl_exec($ch);
	    curl_close($ch);
	    $head = ob_get_contents();
	    ob_end_clean();

	    $regex = '/Content-Length:\s([0-9].+?)\s/';
	    $count = preg_match($regex, $head, $matches);

	    return isset($matches[1]) ? $matches[1] : "0";
    }

    function getRemoteFile($url,$filename = false,$params = false,$cookie = false,$precheck = false)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_URL, $url);

        if ($params) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, base64_decode($params));
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect: ')); // lighttpd fix
        }

        if ($cookie)
        {
            curl_setopt($ch, CURLOPT_COOKIE,base64_decode($cookie));
        }
        else {
            if(preg_match('/([a-z0-9]+)\.com/',$url,$match))
            {
                $name = $match[1];
                $cookieFile = $this->path($this->valReplace($this->cVideoFile));
                $cookieFile = dirname($cookieFile).'/'.$name.'.cookie';
                curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
                curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
            }
        }
        

            
        if ($filename) {

            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 5);

            if($precheck)curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Timeout

            $fp = fopen($filename, 'wb');
            if (!$fp)
            {
                $lastError = "Could not open $filename for writing";
                curl_close($ch);
                return false;
            }
            curl_setopt($ch, CURLOPT_FILE, $fp);
            curl_exec($ch);
            $data = true;
        }
        else
        {
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
            $data = curl_exec($ch);
        }

        $error = curl_error($ch);

        curl_close($ch);

        if (!empty($error) && !($precheck && strstr($error,'timed out')))
        {
            $this->lastError = $error;
            $this->response('Curl Error downloading '.$url,false);
        }

        return $data;
    }

    function resizeImage($sourceImage,$targetImage,$width,$height)
    {
        $srcImg = imagecreatefromjpeg($sourceImage);
        $tmpImg = imagecreatetruecolor($width,$height);

        list($widthOrig, $heightOrig) = getimagesize($sourceImage);

        imagecopyresampled($tmpImg,$srcImg,0,0,0,0,$width,$height,$widthOrig,$heightOrig);
        imagejpeg($tmpImg,$targetImage,100);

        imagedestroy($srcImg);
        imagedestroy($tmpImg);
    }

    /**
     * Initalize Database with new link
     *
     */

    function initDB($config = false)
    {
        if (!$this->database) {
            if (!$config) {
                $configFile = $this->path($this->cConfig);

                if (!is_file($configFile)) {
                    $this->response('Could not find database config file', false);
                }

                include $configFile;
            } else {
                extract($config);
            }

            if (isset($this->cDataBase['extract'])) {
                extract(${$this->cDataBase['extract']});
            }
            // New link due to time out issue

            $this->database['host']     = ${$this->cDataBase['host']};
            $this->database['username'] = ${$this->cDataBase['username']};
            $this->database['password'] = ${$this->cDataBase['password']};
            $this->database['database'] = ${$this->cDataBase['database']};
            $this->database['prefix']   = ${$this->cDataBase['prefix']};

        } 
        
        $this->dbLink = mysql_connect($this->database['host'],$this->database['username'],$this->database['password'],true);
        
        if (!$this->dbLink)
        {
            $this->response('Could not connect to database : '.mysql_error(),false);
        }


        $result = mysql_select_db($this->database['database'], $this->dbLink);

        if (!$result) {
            $this->response('Cant use '.$this->database['database'].' : '.mysql_error(),false);
        }

        if(function_exists('mysql_set_charset')) mysql_set_charset("utf8",$this->dbLink);
        else  mysql_query ('SET NAMES utf8',  $this->dbLink);


        if(isset($this->cDataBase['prefix']))
        {
            $this->cPrefix = $this->database['prefix'];
        }

    }

    /**
     * Check CURL its required for download and Getting Thumbnails
     */

    function checkCurl()
    {
        if (!function_exists('curl_init'))
        {
            $this->response('CURL was not found on the server, please enable it',false);
        }
    }

    /**
     *  Checks video swiper plus connectivity
     */

    function checkAPI()
    {
        if(!$this->cVideoDownload) return;

        $scriptURL = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
        $response = $this->getRemoteFile(VSPLUS.'sync/'.$this->safeEncode($scriptURL));

        if (!strstr($response,'stat="ok"'))
        {
            if (preg_match('%err msg="(.*?)"%',$response,$matches))
            {
                $this->lastError = $matches[1];
            }
            $this->response('Videoswiper API connectivity check Failed',false);
        }
    }

    /**
     * Check Weather required path can be written
     *
     */

    function checkPaths()
    {
        foreach ($this->cPaths as $path)
        {
            if (!is_writable($path))
            {
                $this->response($path." is not writable",false);
            }
        }
    }

    /**
     * Check if Open Base Dir is  on
     *
     */

    function checkOpenBaseDir() {
        $val = ini_get('open_basedir');

        if(!empty($val)) {
            $this->response('Server has open_basedir enabled, please disable it',false);
        }
    }

    /**
     * Returns password hash based on script , override for advanced password generation
     *
     */

    function password()
    {
        return md5($this->post['password']);
    }

    /**
     * Check if valid username is using the script
     *
     */

    function checkLogin()
    {
        global $apiUsers;

        $usersAllowed = empty($apiUsers)?false:explode(',',$apiUsers);

        // is he allowed to use this ?
        if ($usersAllowed && !in_array($this->post['username'],$usersAllowed))
        {
            $this->response('EC101 : This username is not allowed to use this script.',false);
        }

        $username = $this->qs($this->post['username']);
        $password = $this->qs($this->password());

        $conditions = sprintf($this->cUserConditions,$username,$password);

        $this->userId = $this->getField($this->cUserField,$this->cUserTable,$conditions);
        $this->post['uid'] = $this->userId;

        if (!$this->userId)
        {
            $this->response("EC102 : Could not validate username and password",false);
        }

        error_reporting(E_ALL);
        ini_set('display_errors',true);
    }

    /**
     * Check All Default action
     *
     */

    function checkAll()
    {
        $this->checkCurl();
        $this->checkPaths();
        $this->checkOpenBaseDir();
        $this->checkAPI();
        

        $this->response("All checks were successfull");
    }

    /**
     * This is used to make user site as our gateway
     *
     */

    function forward()
    {
        $params = false;
        $cookie = false;
        
        if (isset($this->post['params']))
        {
            $params = $this->post['params'];
        }

        if (isset($this->post['cookie']))
        {
            $cookie = $this->post['cookie'];
        }

        $url = $this->post['url'];

        if(!strstr($url,'http://'))
        {
            $url = $this->safeDecode($url);
        }

        echo $this->getRemoteFile($url,false,$params,$cookie);
    }

    /**
     * Get Categories from user site
     *
     */

    function getInfo()
    {

        list($id,$name) = explode(',',$this->cCategoryFields);

        $where = (empty ($this->cCategoryConditions)?'':' WHERE '.$this->cCategoryConditions);

        $result = $this->query("SELECT ".$this->cCategoryFields." FROM ".$this->cPrefix.$this->cCategoryTable." $where ORDER BY ".$name." ASC");

        $rowCount = mysql_num_rows($result);

        if ($rowCount)
        {
            $categories = "";

            while ($row = mysql_fetch_array($result)) {
                $categories.= '<category id="'.$row[$id].'">'.htmlentities($row[$name]).'</category>'._NL;
            }

            // Supported types

            $actions = "";

            if ($this->cVideoEmbed) {
                $actions .= '<action>embed</action>';
            }
            if ($this->cVideoDownload) {
                $actions .= '<action>download</action>';
                if ($this->cVideoDownloadHD) {
                    $actions .= '<action>downloadhd</action>';
                }
            }
            

            $response = '<categories>'._NL.$categories.'</categories>';
            $response .= _NL.'<actions>'.$actions.'</actions>';

            $this->response($response);

        }

        $this->response('E103 : Could not find any categories.',false);

    }

    /**
    * Viedo Handling functions
    */

    function initPost()
    {

        static $time = _TIME;

        // database stuff

        $this->post['time']        = $time;
        $this->post['mysql_time']  = date('Y-m-d H:i:s',$time);
        $this->post['mysql_date']  = date('Y-m-d',$time);

        $this->post['alias']       = $this->safeURL($this->post['title']);

        $this->post['duration_ms'] = sprintf('%02d:%02d',$this->post['duration']/60,$this->post['duration']%60);
        $this->post['duration_hms'] = sprintf('%02d:%02d:%02d',$this->post['duration']/3600,$this->post['duration']/60,$this->post['duration']%60);

        $this->post['key']         = substr(md5($time.$this->post['title']),0,20);
        $this->post['skey']        = substr(md5($time.$this->post['title']),0,10);

    }

    function getThumbnails() {
        
        global $ffmpeg;

        $videoFilePath = $this->path($this->valReplace($this->cVideoFile));

            $index = 1;
            $interval = $this->post['duration']/(count($this->cVideoThumbs)+1);


            if(is_file($ffmpeg)) {
            // init ffmpeg
            } else if (extension_loaded('ffmpeg'))
            {
                // init ffmpeg
                $handle = new ffmpeg_movie($videoFilePath);
            } else {
                // init normal
            }


            foreach ($this->cVideoThumbs as $thumb) {
            extract($thumb);
            if (!isset($thumb['width']))
                $width = $this->cImageWidth;
            if (!isset($thumb['height']))
                $height = $this->cImageHeight;
            $thumbPath = $this->path($this->valReplace($path));
            $thumbtime = intval($interval * $index);

            if (is_file($ffmpeg) && is_file($videoFilePath)) {
                exec("$ffmpeg -i {$videoFilePath} -f image2  -ss $thumbtime -s {$width}x{$height} -vframes 1 -an -y $thumbPath");
            } else {

                if (!isset($firstImage))
                    $firstImage = $thumbPath;

                if (!is_file($firstImage)) {
                    if (!$this->getRemoteFile($this->post['thumbnail'], $this->cImageTemp)) {
                        $this->response('EC121 : Could not download thumbnail.', false);
                    }
                    $this->resizeImage($this->cImageTemp, $thumbPath, $width, $height);
                } else {
                    $this->resizeImage($firstImage, $thumbPath, $width, $height);
                }
            }
            $index++;
        }


    }

    function getDuration() {
        global $ffmpeg;

        $videoFilePath = $this->path($this->valReplace($this->cVideoFile));

        if ($this->post['duration'] == 0) {
            if(is_file($ffmpeg)) {
                ob_start();
                passthru("$ffmpeg -i {$videoFilePath} 2>&1");
                $duration = ob_get_contents();
                ob_end_clean();


                if(preg_match('/Duration: (.*?),/', $duration, $matches, PREG_OFFSET_CAPTURE, 3)) {
                    $this->post['duration'] = $matches[1][0];
                }

            }

        }

    }



    function downloadVideo($precheck = false) {

        global $ffmpeg;
        
        $videoPath = $this->path($this->valReplace($this->cVideoFile));
        $this->cVideoFilePath = $videoPath;

        $scriptURL = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
        
        if(!isset($this->post['downloadURL'])) {

            // get download URL
            $downloadAPIURL = VSPLUS.'get/'.$this->post['token'].'/'.$this->safeEncode($this->post['permalink']).'/'.$this->safeEncode($scriptURL.'|'.$this->post['username'].'|'.$this->post['password']);
            // if ! flv file do something
            $response = $this->getRemoteFile($downloadAPIURL);


            if (preg_match('%err msg="(.*?)"%',$response,$matches))
            {
                $this->lastError = $matches[1];
            }

            if(!$response || empty($response) || strstr($response,'stat="Fail"')) {
                $this->response('EC111 : Could not get download URL using API.',false);
            }
        }

        
        if(isset($this->post['downloadURL']) || preg_match('%<download>(.*?)</download>%',$response,$match)) {
            if(!isset($this->post['downloadURL']))$this->post['downloadURL'] = $match[1];

            set_time_limit(0); // can take long

            @unlink($videoPath);
            if (!$this->getRemoteFile($this->post['downloadURL'],$videoPath,false,false,$precheck)) {
                $this->response('EC112 : Could not download video file.',false);
            }

            // get size
            static $rsize = 0;

            if(!isset($this->post['size'])) {
                $rsize = $this->getremoteFileSize($this->post['downloadURL']);
            }

            // automatic mp4 conversion


                $fp =fopen($videoPath,"r");
                if(!$fp)
                {
                    $this->response('EC113 : Could not open downloaded video file.',false);
                }
                $header = fread($fp,3);
                fclose($fp);

                if($header != 'FLV')
                {
                    // Convert Video mp4 to flv
                    //ffmpeg -i input.mov -ar 22050 -qscale .1 output.flv
                    if($this->cMp4File)
                    {
                        $this->cMp4FilePath = $this->path($this->valReplace($this->cMp4File));
                        copy($videoPath,$this->cMp4FilePath);
                    }

                    if (!$precheck) {
                    if (is_file($ffmpeg) && !$this->cMp4Only) {
                        $tempPath = "{$videoPath}.tmp.flv";
                        exec("$ffmpeg -i {$videoPath} -ar 22050 -qscale 11 -s 320x240 {$tempPath} 2>&1", $return);
                        if (is_file($tempPath) && (filesize($tempPath) > 1024)) {
                            copy($tempPath, $videoPath);
                            $this->cVideoFilePath = $videoPath;
                            unlink($tempPath);
                        } else {
                            echo implode("\n", $return);
                        }
                    }                
                }
            }

            $size = filesize($videoPath);

            if($rsize > $size) {
                $size = $rsize;
            }

            $this->post['size'] = $size;
            $this->post['size_kb'] = sprintf("%.2f",$size/(1024));
            $this->post['size_KB'] = sprintf("%.2f KB",$size/(1024));
            $size /= 1024;
            $this->post['size_mb'] = sprintf("%.2f",$size/(1024));
            $this->post['size_MB'] = sprintf("%.2f MB",$size/(1024*1024));

            // get Video Duration

            $this->getDuration();
            return ;
        }

        $this->response('EC114 : No download link in API response.',false);
    }

    function uploadVideo()
    {
        $s = $this->server;

        $conn = ftp_connect($s['hostname']);
        if(!$conn)
        {
            $this->response('EC151 : Could not connect to '.$s['hostname'],false);
        }

        $result = ftp_login($conn, $s['username'], $s['password']);
        if(!$result)
        {
            $this->response('EC152 : Could not login to '.$s['hostname'],false);
        }

        // creat anyway
        ftp_mkdir($conn,$s['path']);

        $localFile  = $this->path($this->valReplace($this->cVideoFile));

        $remoteFile = $s['path'].($s['path'][strlen($s['path'])-1]=='/'?'':'/').basename($localFile);

        $result = ftp_put($conn,$remoteFile,$localFile,FTP_BINARY);
        if(!$result)
        {
            $this->response('EC153 : Could not upload '.$localFile.' to '.$remoteFile.' on '.$s['hostname'],false);
        }

        if($this->cMp4File && $this->cMp4FilePath)
        {
            $localFile  = $this->path($this->valReplace($this->cMp4File));

            $remoteFile = $s['path'].($s['path'][strlen($s['path'])-1]=='/'?'':'/').basename($localFile);

            $result = ftp_put($conn,$remoteFile,$localFile,FTP_BINARY);
            if(!$result)
            {
                $this->response('EC154 : Could not upload '.$localFile.' to '.$remoteFile.' on '.$s['hostname'],false);
            }
        }

        ftp_close($conn);

        unlink($localFile);

    }
    
    function getServer()
    {
        if(!$this->cServerVarMap) return false;
        $where = (empty ($this->cServerConditions)?'':' WHERE '.$this->cServerConditions);
 
        $result = $this->query("SELECT * FROM ".$this->cPrefix.$this->cServerTable.$where);

        $rowCount = mysql_num_rows($result);

        if ($rowCount)
        {
            $row = mysql_fetch_assoc($result);

            $m = $this->cServerVarMap;
            $this->server['id'] = $row[$m['id']];
            $this->server['hostname'] = $row[$m['hostname']];
            $this->server['username'] = $row[$m['username']];
            $this->server['password'] = $row[$m['password']];
            $this->server['path']     = $row[$m['path']];
            $this->server['url']      = $row[$m['url']];

            $this->post['server_id']   = $row[$m['id']];
            $this->post['server_path'] = $row[$m['path']];
            $this->post['server_url']  = $row[$m['url']];

            return true;
        }

        return false;
    }



    /**
    * Embed
    */

    function embed()
    {
        $this->initPost();

        $this->getThumbnails();

        $result = $this->queryCreate($this->cVideoTable,$this->cVideoVarMap);
        $this->post['id'] = mysql_insert_id();
        return $result;
    }


    /**
    * Download
    */

    function download()
    {
    	 $this->initPost();

    	 // Precheck  ( video file + size + duration )
    	 $this->downloadVideo(true);

    	 $this->getThumbnails();

    	 $this->queryCreate($this->cVideoTable,$this->cVideoVarMap);
         $this->post['id'] = mysql_insert_id();
         
    	 $this->downloadVideo();

    	 $this->getThumbnails();

         if($this->getServer())
         {
             $this->uploadVideo();
             $this->queryUpdate($this->cVideoTable,$this->cServerUpdateVarMap,$this->cVideoField. ' = '.$this->post['id']);
         }

         if($this->cVideoUpdateVarMap)
         $this->queryUpdate($this->cVideoTable,$this->cVideoUpdateVarMap,$this->cVideoField. ' = '.$this->post['id']);

    }

    /**
     * The main executing function
     *
     */

    function dispatch()
    {

        if (is_array($_POST) && count($_POST) && ($_POST['action']!='sync') ) {
            $this->checkLogin();
        }

        $action = (isset($_POST['action']))?$_POST['action']:'default';
        $this->action = $action;

    

    switch ($action)
        {

            case 'login':
                break;

            case 'info':
                $this->getInfo();
                break;

            case 'embed':
                $this->embed();
                break;

            case 'downloadhd':
            case 'download':
            	$this->download();
                break;

            case 'forward':
                $this->forward();
                break;

            case 'sync':
                $this->response("");
                break;

            default:
                $this->checkAll();
                break;
        }

        $this->response("");

    }

}
?>
<?php
define('SITE_URL', "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . ((dirname($_SERVER['PHP_SELF']) == '/' ) ? '' : '/'));

class smartvideoplus extends vsmod {
    /* Wordpress support */

    function wpPostXMLRPC($title, $body, $username, $password, $category, $keywords='') {
        $title = htmlentities($title, ENT_NOQUOTES);
        $keywords = htmlentities($keywords, ENT_NOQUOTES);

        $content = array(
            'title' => $title,
            'description' => $body,
            'mt_allow_comments' => 1, // 1 to allow comments
            'mt_allow_pings' => 1, // 1 to allow trackbacks
            'post_type' => 'post',
            //'post_status' => 'draft',
            'categories' => array($category),
            'mt_keywords' => $keywords
        );
        
        $content['custom_fields']    = array(array('key' => 'videoswiper-embed-code','value' => stripslashes($_POST['embed'])), array('key' => 'videoswiper-embed-thumb', 'value' => $_POST['thumb']));
        $params = array(0, $username, $password, $content, true);
        $request = xmlrpc_encode_request('metaWeblog.newPost', $params);
        $results = $this->getRemoteFile(SITE_URL . 'xmlrpc.php', false, base64_encode($request));

        return $results;
    }

    function wpEditXMLRPC($postId, $title, $body, $username, $password) {
        $title = htmlentities($title, ENT_NOQUOTES);

        $content = array(
            'title' => $title,
            'description' => $body
            //'post_status' => 'draft'
        );
        $params = array($postId, $username, $password, $content, true);
        $request = xmlrpc_encode_request('metaWeblog.editPost', $params);
        $results = $this->getRemoteFile(SITE_URL . 'xmlrpc.php', false, base64_encode($request));

        return $results;
    }

    function wpCategoriesXMLRPC($username, $password) {
        $params = array(0, $username, $password, array(), true);
        $request = xmlrpc_encode_request('wp.getCategories', $params);
        $results = $this->getRemoteFile(SITE_URL . 'xmlrpc.php', false, base64_encode($request));
        return $results;
    }

    function wpUserXMLRPC($username, $password) {
        $params = array(0, $username, $password, array(), true);
        $request = xmlrpc_encode_request('blogger.getUserInfo', $params);
        $results = $this->getRemoteFile(SITE_URL . 'xmlrpc.php', false, base64_encode($request));
        return $results;
    }

    
    var $cConfig = "wp-config.php";
    var $cDataBase = array('host' => 'DBHOST', 'username' => 'DBUSER', 'password' => 'DBPASSWORD', 'database' => 'DBNAME', 'prefix' => 'DBPRIFIX');

    function initDB() {
        $config_file = file_get_contents($this->cConfig);

        preg_match('/\'DB_HOST\',[\s]+\'(.[^\']*?)\'/s', $config_file, $DBHOST);
        preg_match('/\'DB_USER\',[\s]+\'(.[^\']*?)\'/s', $config_file, $DBUSER);
        preg_match('/\'DB_PASSWORD\',[\s]+\'(.[^\']*?)\'/s', $config_file, $DBPASSWORD);
        preg_match('/\'DB_NAME\',[\s]+\'(.[^\']*?)\'/s', $config_file, $DBNAME);
        preg_match('/\$table_prefix[\s]+=[\s]+\'(.[^\']*?)\'/s', $config_file, $DBPRIFIX);

        $config = array();
        $config['DBHOST'] = $DBHOST[1];
        $config['DBUSER'] = $DBUSER[1];
        $config['DBPASSWORD'] = $DBPASSWORD[1];
        $config['DBNAME'] = $DBNAME[1];
        $config['DBPRIFIX'] = $DBPRIFIX[1];
        parent::initDB($config);
    }
    
    /* video common */
    var $cVideoFile = 'videos/video.flv';
    var $cPaths = array('thumbs');
    var $cImageTemp = 'thumbs/temp.jpg';
    var $cVideoThumbs = array(array('path' => 'thumbs/{$skey}.jpg'));   

    function checkLogin() {
        global $apiUsers, $rpcURL;

        $usersAllowed = empty($apiUsers) ? false : explode(',', $apiUsers);

        // is he allowed to use this ?
        if ($usersAllowed && !in_array($this->post['username'], $usersAllowed)) {
            $this->response('This username is not allowed to use this script.', false);
        }

        $username = $this->post['username'];
        $password = $this->post['password'];

        $result = $this->wpUserXMLRPC($_POST['username'], $_POST['password']);

        if (strstr($result, 'faultCode')) {
            $this->response('Could not validate username and password.', false);
        }

        if (preg_match('%<name>userid</name><value><string>([0-9]+)</string>%', $result, $match)) {
            return $match[1];
        }
        $this->response('Could not get User ID.', false);
    }

    function getInfo() {

        $result = $this->wpCategoriesXMLRPC($_POST['username'], $_POST['password']);

        if (strstr($result, 'faultCode')) {
            $this->response('Could not get Categories.', false);
        }

        if (preg_match_all('%<name>categoryId</name><value><string>([0-9]+)</string>%', $result, $matchIds) && preg_match_all('%<name>categoryName</name><value><string>(.[^<]*?)</string>%', $result, $matchNames)) {
            $categories = "";

            for ($i = 0; $i < count($matchIds[1]); $i++) {
                $categories.= '<category id="' . intval($matchIds[1][$i]) . '">' . $matchNames[1][$i] . '</category>' . _NL;
            }
            $actions = "";
            $actions .= '<action>embed</action>';

            $response = '<categories>' . _NL . $categories . '</categories>';
            $response .= _NL . '<actions>' . $actions . '</actions>';

            $this->response($response);
        }
        $this->response('Could not get Categories.', false);
    }

    function embed() {
        $this->initPost();
        extract($_POST);

        $this->getThumbnails();
        $_POST['thumb'] = $this->valReplace('/thumbs/{$skey}.jpg');
        // post to wordpress
        $tagsArray = explode(',', $tags);
        $nTags = array();
        foreach ($tagsArray as $tag) {
            $safe = $this->safeURL($tag);
            $nTags[$safe] = $tag;
        }
        $nTags = array_keys($nTags);

        $nTags = implode(',', $nTags);

        $result = $this->wpPostXMLRPC($title, $description, $_POST['username'], $_POST['password'], $category_name, $nTags);
        preg_match('%<string>([0-9]+)</string>%s', $result, $matchIds);
        $postId = $matchIds[1];
        if ($postId) {
            $this->queryUpdate('posts', array('#post_content' => $description, '#post_title' => $title), 'ID=' . $postId);
        }
        $this->response("");
    }

    function checkAll()
    {

        if (!function_exists('xmlrpc_encode_request'))
        {
            $this->response('xmlrpc_encode_request is not defined.Please ask host to enable XML-RPC extension.',false);
        }
        parent::checkAll();
    }

}

$object = new smartvideoplus();

$object->dispatch();